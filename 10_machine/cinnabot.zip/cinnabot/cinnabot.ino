#include <AccelStepper.h>

const int m1dirPin = 23;
const int m1stepPin = 22;

const int m2dirPin = 14;
const int m2stepPin = 12;

const int A1A = 19;  // define pin 12 for A-1A 


const int buttonPin = 27;
int buttonState = 0;
bool forwardMoveTriggered = false;

// Define some steppers and the pins they will use
AccelStepper rotStepper(AccelStepper::DRIVER, m1stepPin, m1dirPin);
AccelStepper radStepper(AccelStepper::DRIVER, m2stepPin, m2dirPin);


void setup(){  
    pinMode(buttonPin, INPUT);
    Serial.begin(9600);
    pinMode(A1A, OUTPUT);     // specify these pins as outputs
    digitalWrite(A1A, LOW);   // start with the motors off 

    rotStepper.setMaxSpeed(1500.0);
    rotStepper.setAcceleration(1000.0);
 

    radStepper.setMaxSpeed(1000.0);
    radStepper.setAcceleration(200.0);
    radStepper.setSpeed(-200);

    // // Initially set the motor to run backwards continuously
    //    // Large negative value to keep it moving backwards
    while(digitalRead(buttonPin) == 0){
      radStepper.runSpeed();
    }
    radStepper.setCurrentPosition(0);
    radStepper.move(2025);

    while(radStepper.distanceToGo() != 0) {
      radStepper.run();
    }

    digitalWrite(A1A, HIGH);

    delay(500);
    digitalWrite(A1A, LOW);

    // move out from center
    radStepper.move(12000);
    while(radStepper.distanceToGo() != 0) {
      radStepper.run();
    }

    rotStepper.move(18200);
    digitalWrite(A1A, HIGH);
    while(rotStepper.distanceToGo() != 0) {
      rotStepper.run();
    }
    digitalWrite(A1A, LOW);

    Serial.println("Moving X");
    radStepper.move(-3000);
    while(radStepper.distanceToGo() != 0) {
      radStepper.run();
    }

    // circle
    rotStepper.setCurrentPosition(0);
    
    rotStepper.move(-18200);
    digitalWrite(A1A, HIGH);
    while(rotStepper.distanceToGo() != 0) {
      rotStepper.run();
    }
    digitalWrite(A1A, LOW);

    radStepper.move(-3000);
    while(radStepper.distanceToGo() != 0) {
      radStepper.run();
    }

    rotStepper.move(18200);
    digitalWrite(A1A, HIGH);
    while(rotStepper.distanceToGo() != 0) {
      rotStepper.run();
    }

    digitalWrite(A1A, LOW);
    radStepper.move(-3000);
    while(radStepper.distanceToGo() != 0) {
      radStepper.run();
    }
    // circle
    rotStepper.move(-18200);
    digitalWrite(A1A, HIGH);
    while(rotStepper.distanceToGo() != 0) {
      rotStepper.run();
    }
    digitalWrite(A1A, LOW);

    
    //   rotStepper.move(18200);
    //   digitalWrite(A1A, HIGH);
    // while(rotStepper.distanceToGo() != 0) {
    //   rotStepper.run();
    // }
    // // circle
    // rotStepper.move(-18200);
    // while(rotStepper.distanceToGo() != 0) {
    //   rotStepper.run();
    // }

    // digitalWrite(A1A, LOW);

    
    
}
void loop(){ 
}
