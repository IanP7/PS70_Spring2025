#include <ESP_I2S.h>
#include "Sound.h"

// const int buff_size = 2;
// int available_bytes, read_bytes;
// uint8_t buffer[buff_size];
#define sample_rate 48000.0
// LED pin
#define LED_PIN 33
I2SClass I2S;

// LED variables
unsigned long previousLEDMillis = 0;
const long ledInterval = 500;  // blink interval in ms
bool ledState = LOW;

void setup() {
  // Initialize LED
  pinMode(LED_PIN, OUTPUT);
  I2S.setPins(26, 25, 27, -1, -1);  //SCK, WS, SDOUT, SDIN, MCLK
  I2S.begin(I2S_MODE_STD, sample_rate, I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_MONO);
  // I2S.configureTX(sample_rate, I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_STEREO);
  // I2S.read();
  // available_bytes = I2S.available();
  // if(available_bytes < buff_size) {
  //   read_bytes = I2S.readBytes(buffer, available_bytes);
  // } else {
  //   read_bytes = I2S.readBytes(buffer, buff_size);
  // }

  Serial.begin(115200);
}

void loop() {
  Serial.println("playing the sound");
  for (float i = 0; i < 572326; i++) {
    // Handle LED blinking (non-lobotomizing)
    unsigned long currentMillis = millis();
    if (currentMillis - previousLEDMillis >= ledInterval) {
      previousLEDMillis = currentMillis;
      ledState = !ledState;
      digitalWrite(LED_PIN, ledState);
    }
    //convert 8 bit to 16 bit
    uint16_t sample = map(Test[(int)(i)], 0, 255, 0, 32767);

    //you can only write an 8bit integer at a time so we read the 16 bit integer, 8 bits at a time
    I2S.write((uint8_t *)&sample, 2);
    // I2S.write((uint8_t *)&sample, 2);
  }
}