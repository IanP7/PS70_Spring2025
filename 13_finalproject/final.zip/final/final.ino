/**
 * Temperature Control System with Dual BMP280 Sensors
 * 
 * This program implements a temperature control system using:
 * - Two BMP280 temperature sensors for accurate temperature readings
 * - OLED display for real-time feedback
 * - Rotary encoder for temperature adjustment
 * - Three heating pads with hysteresis control
 * - Status LEDs to indicate heating/ready states
 * 
 * Features:
 * - Adjustable target temperature (80°F-150°F)
 * - Temperature lock mechanism with timeout
 * - Hysteresis control to prevent rapid cycling
 * - Visual feedback through OLED display and status LEDs
 */

#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_BMP280.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_SSD1306.h>
#include <Adafruit_GFX.h>

// Create sensor objects with their I2C addresses
Adafruit_BMP280 bmp1; // First BMP280 (0x76)
Adafruit_BMP280 bmp2; // Second BMP280 (0x77)

// OLED display settings
#define SCREEN_WIDTH 128 // OLED display width, in pixels
#define SCREEN_HEIGHT 32 // OLED display height, in pixels (0.91" display)
#define OLED_RESET    -1 // Reset pin # (or -1 if sharing Arduino reset pin)
#define SCREEN_ADDRESS 0x3C // Common I2C address for 0.91" OLED
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// Heat Pad Control Pins
#define HEAT_PAD_1 8    // Digital pin D8
#define HEAT_PAD_2 10   // Digital pin D10
#define HEAT_PAD_3 9    // Digital pin D9

// Status LED Pins
#define HEATING_LED D1  // LED indicates heating is active
#define READY_LED D0    // LED indicates temperature is in target range

// Rotary Encoder Pins
#define CLK D6          // Clock pin
#define DT D3           // Data pin
#define SW D7           // Switch pin (button for locking/unlocking)

// Temperature Range Settings
#define MIN_TEMP_F 80   // Minimum target temperature (F)
#define MAX_TEMP_F 150  // Maximum target temperature (F)
float targetTempF = 100.0; // Default target temperature (F)

// Temperature Control Parameters
float hysteresis = 2.0;     // Temperature must drop this much below target before reheating (in °F)
bool tempInRange = false;   // Flag to track if temperature is within acceptable range

// Encoder Variables
int counter = 20;       // Starting value (100°F = MIN_TEMP_F + counter)
int currentStateCLK;    // Current state of CLK pin
int currentStateDT;     // Current state of DT pin
int lastStateCLK;       // Previous state of CLK pin
int lastStateDT;        // Previous state of DT pin
bool encoderMoving = false;  // Tracks encoder movement state

// Button and Lock Variables
bool isLocked = true;                // Start with temperature adjustment locked
int lastButtonState = HIGH;          // Button uses pull-up resistor (HIGH when not pressed)
unsigned long lastEncoderActivity = 0;
const long lockTimeout = 5000;       // Auto-lock after 5 seconds of inactivity

// Debounce Variables
unsigned long lastButtonTime = 0;    // Time of last button state change
const long buttonDebounceTime = 50;  // Minimum time between button state changes (ms)

/**
 * Converts temperature from Celsius to Fahrenheit
 */
float celsiusToFahrenheit(float celsius) {
  return celsius * 1.8 + 32.0;
}

void setup() {
  // Initialize serial communication
  Serial.begin(115200);
  delay(1000);
  Serial.println("\n\nBMP280 Temperature Control System");
  
  // Initialize I2C communication
  Wire.begin();
  
  // Configure rotary encoder pins
  pinMode(CLK, INPUT);
  pinMode(DT, INPUT);
  pinMode(SW, INPUT_PULLUP); // Button with internal pull-up resistor
  
  // Read initial encoder pin states
  lastStateCLK = digitalRead(CLK);
  lastStateDT = digitalRead(DT);
  
  // Configure output pins
  pinMode(HEAT_PAD_1, OUTPUT);
  pinMode(HEAT_PAD_2, OUTPUT);
  pinMode(HEAT_PAD_3, OUTPUT);
  pinMode(HEATING_LED, OUTPUT);
  pinMode(READY_LED, OUTPUT);
  
  // Initialize all outputs to safe state
  digitalWrite(HEAT_PAD_1, LOW);
  digitalWrite(HEAT_PAD_2, LOW);
  digitalWrite(HEAT_PAD_3, LOW);
  digitalWrite(HEATING_LED, LOW);
  digitalWrite(READY_LED, HIGH); // Ready LED on initially
  
  // Initialize target temperature and counter
  targetTempF = 100.0;
  counter = 20; // Maps to initial target temperature (100-80=20)
  
  // Initialize OLED display
  if(!display.begin(SSD1306_SWITCHCAPVCC, SCREEN_ADDRESS)) {
    Serial.println("SSD1306 allocation failed");
    while(1); // Don't proceed if display fails
  }
  
  // Show startup message on display
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0,0);
  display.println("Initializing...");
  display.display();
  
  // Initialize first BMP280 sensor
  if (!bmp1.begin(0x76)) {
    Serial.println("Could not find BMP280 #1!");
    display.println("BMP280 #1 failed!");
    display.display();
    while(1); // Don't proceed if sensor fails
  }
  
  // Initialize second BMP280 sensor
  if (!bmp2.begin(0x77)) {
    Serial.println("Could not find BMP280 #2!");
    display.println("BMP280 #2 failed!");
    display.display();
    while(1); // Don't proceed if sensor fails
  }
  
  // All components initialized successfully
  display.println("All sensors OK!");
  display.println("Starting...");
  display.display();
  delay(1000);
  
  Serial.println("Setup complete - Temperature adjustment locked");
}

/**
 * Updates the OLED display with current system status
 */
void updateDisplay(float temp1F, float temp2F, float avgTempF, float targetF, bool heating, bool locked, bool inRange) {
  display.clearDisplay();
  
  // Display individual sensor temperatures
  display.setCursor(0,0);
  display.print("T1:");
  display.print(temp1F, 1);
  display.print("F  T2:");
  display.print(temp2F, 1);
  display.println("F");
  
  // Display average temperature
  display.print("Avg:");
  display.print(avgTempF, 1);
  display.println("F");
  
  // Display target temperature with lock indicator
  display.print("Target: ");
  display.print(targetF, 1);
  display.print("F ");
  display.print(locked ? "[L]" : "[U]");
  
  // Display current system status
  display.setCursor(0, 24);  // Position on last line
  display.print("Status: ");
  if (inRange) {
    display.print("IN RANGE ");
  } else {
    display.print(heating ? "HEATING " : "COOLING ");
  }
  
  display.display();
}

/**
 * Handles the button press for locking/unlocking temperature adjustment
 */
void handleButtonPress() {
  // Read the current button state
  int buttonState = digitalRead(SW);
  
  // Apply debounce to prevent false triggers
  if ((millis() - lastButtonTime) > buttonDebounceTime) {
    // Detect button press (transition from HIGH to LOW)
    if (buttonState == LOW && lastButtonState == HIGH) {
      // Toggle lock state
      isLocked = !isLocked;
      
      // Update the last button press time
      lastButtonTime = millis();
      
      // Log status change
      if (isLocked) {
        Serial.println("Button pressed! Temperature LOCKED manually");
      } else {
        Serial.println("Button pressed! Temperature UNLOCKED");
        // Reset activity timer when unlocking
        lastEncoderActivity = millis();
      }
    }
  }
  
  // Save button state for next comparison
  lastButtonState = buttonState;
}

/**
 * Controls heating elements based on current and target temperatures
 * Implements hysteresis to prevent rapid cycling of heating elements
 */
void controlTemperature(float temp1F, float temp2F, float avgTempF, float targetF) {
  bool heatingState = false;
  
  // Implement hysteresis control logic based on average temperature
  if (avgTempF >= targetF) {
    // Turn heat OFF when temperature reaches or exceeds target
    digitalWrite(HEAT_PAD_1, LOW);
    digitalWrite(HEAT_PAD_2, LOW);
    digitalWrite(HEAT_PAD_3, LOW);
    // Update status LEDs
    digitalWrite(HEATING_LED, LOW);  // Heating LED off when not heating
    digitalWrite(READY_LED, HIGH);   // Ready LED on when temperature reached
    heatingState = false;
    
    // Mark temperature as in range
    tempInRange = true;
    
    Serial.print("Temperature reached target (");
    Serial.print(targetF, 1);
    Serial.println("F) - Heat OFF");
  } 
  else if (!tempInRange || avgTempF < (targetF - hysteresis)) {
    // Turn heat ON if:
    // 1. We haven't reached target temperature yet (tempInRange is false)
    // OR
    // 2. Temperature has dropped below target minus hysteresis
    digitalWrite(HEAT_PAD_1, HIGH);
    digitalWrite(HEAT_PAD_2, HIGH);
    digitalWrite(HEAT_PAD_3, HIGH);
    // Update status LEDs
    digitalWrite(HEATING_LED, HIGH); // Heating LED on when heating
    digitalWrite(READY_LED, LOW);    // Ready LED off when heating
    heatingState = true;
    
    // Log when temperature drops below hysteresis threshold
    if (tempInRange && avgTempF < (targetF - hysteresis)) {
      tempInRange = false;
      Serial.print("Temperature dropped below threshold (");
      Serial.print(targetF - hysteresis, 1);
      Serial.println("F) - Heat ON");
    }
  }
  
  // Update display with current system state
  updateDisplay(temp1F, temp2F, avgTempF, targetF, heatingState, isLocked, tempInRange);
}

void loop() {
  // Check for lock/unlock button press
  handleButtonPress();
  
  // Auto-lock feature: Check for timeout if currently unlocked
  if (!isLocked && (millis() - lastEncoderActivity > lockTimeout)) {
    isLocked = true;
    Serial.println("Temperature LOCKED due to inactivity timeout");
  }
  
  // Read temperatures from both sensors
  float temp1C = bmp1.readTemperature();
  float temp2C = bmp2.readTemperature();
  float temp1F = celsiusToFahrenheit(temp1C);
  float temp2F = celsiusToFahrenheit(temp2C);
  float avgTempF = (temp1F + temp2F) / 2.0;
  
  // Read current encoder pin states
  currentStateCLK = digitalRead(CLK);
  currentStateDT = digitalRead(DT);

  // Process encoder input only if temperature adjustment is unlocked
  if (!isLocked) {
    // Check if encoder pins are mismatched (encoder is moving)
    if (currentStateCLK != currentStateDT) {
      encoderMoving = true;
    } 
    // If pins match and encoder was moving, we completed a rotation step
    else if (encoderMoving) {
      // Determine rotation direction based on which pin changed state first
      if (lastStateCLK != lastStateDT) {
        if (lastStateCLK == currentStateCLK) {
          // DT changed first (Counter-Clockwise rotation)
          counter--;
          Serial.println("CCW click detected");
        } else {
          // CLK changed first (Clockwise rotation)
          counter++;
          Serial.println("CW click detected");
        }
        
        // Constrain counter to valid range and update target temperature
        counter = constrain(counter, 0, 70); // 0 to 70 maps to 80°F to 150°F
        targetTempF = MIN_TEMP_F + counter;
        
        // Reset inactivity timer
        lastEncoderActivity = millis();
        
        Serial.print("Counter: ");
        Serial.print(counter);
        Serial.print(" | Target temperature: ");
        Serial.print(targetTempF);
        Serial.println(" F");
      }
      
      // Reset the moving flag
      encoderMoving = false;
    }
  }
  
  // Save current encoder states for next comparison
  lastStateCLK = currentStateCLK;
  lastStateDT = currentStateDT;
  
  // Periodically log sensor readings to serial monitor
  static unsigned long lastPrintTime = 0;
  if (millis() - lastPrintTime > 500) {
    Serial.print("T1:");
    Serial.print(temp1F);
    Serial.print("F, T2:");
    Serial.print(temp2F);
    Serial.print("F, Avg:");
    Serial.print(avgTempF);
    Serial.print("F, Target:");
    Serial.print(targetTempF);
    Serial.print("F, Lock:");
    Serial.print(isLocked ? "L" : "U");
    Serial.print(", Status:");
    Serial.println(tempInRange ? "IN RANGE" : "OUT OF RANGE");
    lastPrintTime = millis();
  }
  
  // Control heating elements based on current temperature
  controlTemperature(temp1F, temp2F, avgTempF, targetTempF);
  
  // Small delay for stability
  delay(10);
}