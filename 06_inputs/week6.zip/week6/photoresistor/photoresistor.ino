int sensorPin = 33;
int ledPin = 25;  // LED pin
unsigned long previousMillis = 0;  
const long interval = 100;         

// Simple rolling average with 100 readings
const int numReadings = 100;
int readings[100];
int readIndex = 0;

void setup() {
  Serial.begin(9600);
  pinMode(sensorPin, INPUT);
  pinMode(ledPin, OUTPUT);
}

void loop() {
  unsigned long currentMillis = millis();
  
  if (currentMillis - previousMillis >= interval) {
    previousMillis = currentMillis;
    
    // Get new reading
    int val = analogRead(sensorPin);
    
    // Update rolling array
    readings[readIndex] = val;
    readIndex = (readIndex + 1) % numReadings;
    
    // Calculate simple average
    int sum = 0;
    for (int i = 0; i < numReadings; i++) {
      sum += readings[i];
    }
    int average = sum / numReadings;
    
    // Turn LED on if average is >= 2830, otherwise off
    if (average >= 2715) {
      digitalWrite(ledPin, HIGH);
    } else {
      digitalWrite(ledPin, LOW);
    }
    
    // Print the average
    Serial.println(average);
  }
}