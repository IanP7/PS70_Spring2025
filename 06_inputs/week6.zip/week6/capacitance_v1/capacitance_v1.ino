long result;   //variable for the result of the tx_rx measurement.
int analog_pin = A5;
int tx_pin = 25;

// Rolling average variables
const int AVERAGE_SIZE = 1000;     // Number of points in rolling average
long readings[AVERAGE_SIZE];     // Array to store readings
int readIndex = 0;               // Current position in array
long total = 0;                  // Running total
bool arrayFilled = false;        // Flag for initial filling of array

// Timing variables
unsigned long previousMicros = 0;

void setup() {
    pinMode(tx_pin, OUTPUT);      //Pin 4 provides the voltage step
    Serial.begin(9600);
    
    // Initialize readings array
    for (int i = 0; i < AVERAGE_SIZE; i++) {
        readings[i] = 0;
    }
}

void loop() {
    result = tx_rx();
    
    // Update rolling average
    total = total - readings[readIndex];
    readings[readIndex] = result;
    total = total + result;
    
    readIndex++;
    if (readIndex >= AVERAGE_SIZE) {
        readIndex = 0;
        arrayFilled = true;
    }
    
    // Calculate average
    long average;
    if (arrayFilled) {
        average = total / AVERAGE_SIZE;
    } else {
        average = total / (readIndex == 0 ? 1 : readIndex);
    }
    
    // Print results
    Serial.print("Raw: ");
    Serial.print(result);
    Serial.print(", Avg: ");
    Serial.println(average);
}


long tx_rx(){         // Function to execute rx_tx algorithm and return a value
                      // that depends on coupling of two electrodes.
                      // Value returned is a long integer.
  int read_high;
  int read_low;
  int diff;
  long int sum;
  int N_samples = 100;    // Number of samples to take.  Larger number slows it down, but reduces scatter.

  sum = 0;

  for (int i = 0; i < N_samples; i++){
   digitalWrite(tx_pin,HIGH);              // Step the voltage high on conductor 1.
   read_high = analogRead(analog_pin);     // Measure response of conductor 2.
   
   // Replace delayMicroseconds with millis-based timing
   previousMicros = micros();
   while (micros() - previousMicros < 100); // Wait 100 microseconds
   
   digitalWrite(tx_pin,LOW);               // Step the voltage to zero on conductor 1.
   read_low = analogRead(analog_pin);      // Measure response of conductor 2.
   diff = read_high - read_low;            // desired answer is the difference between high and low.
   sum += diff;                            // Sums up N_samples of these measurements.
 }
  return sum;
}