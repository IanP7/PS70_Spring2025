class Thermistor {
private:
  int thermistorPin;
  float r1;
  float r2;

public:
  Thermistor(int pin, float resistor1)
    : thermistorPin(pin), r1(resistor1) {}

  float readTemperature() {
    int vo = analogRead(thermistorPin);
    r2 = r1 * (1.0 / (4095.0 / (float)vo - 1.0));
    return -33.532 * log(r2) + 410.85;
  }
};

class TemperatureControl {
private:
  // Pins
  int heatPadPin;
  int heatingLED;
  int readyLED;
  int potPin;

  // State
  bool heatPadOn;

  // Temperature control parameters
  float targetTemp;
  float tempRange;
  float minTemp;
  float maxTemp;

  // Rolling average
  static const int AVERAGE_SIZE = 100;
  float tempReadings[AVERAGE_SIZE];
  int readIndex;
  float tempTotal;
  bool arrayFilled;

  // Thermistor
  Thermistor* thermistor;

public:
  TemperatureControl(int thermPin, int heatPin, int heatLed, int readyLed, int potentiometer)
    : heatPadPin(heatPin),
      heatingLED(heatLed),
      readyLED(readyLed),
      potPin(potentiometer),
      heatPadOn(false),
      targetTemp(82.0),
      tempRange(1.0),
      minTemp(75.0),
      maxTemp(95.0),
      readIndex(0),
      tempTotal(0.0),
      arrayFilled(false) {

    thermistor = new Thermistor(thermPin, 10000);

    // Initialize readings array
    for (int i = 0; i < AVERAGE_SIZE; i++) {
      tempReadings[i] = 0;
    }
  }

  ~TemperatureControl() {
    delete thermistor;
  }

  void setup() {
    // Set pin modes
    pinMode(heatPadPin, OUTPUT);
    pinMode(heatingLED, OUTPUT);
    pinMode(readyLED, OUTPUT);
    pinMode(potPin, INPUT);

    // Initially turn heat pad and LEDs off
    digitalWrite(heatPadPin, LOW);
    digitalWrite(heatingLED, LOW);
    digitalWrite(readyLED, LOW);
    heatPadOn = false;
  }

  void updateTargetTemperature() {
    // Read the potentiometer to set the target temperature
    int potValue = analogRead(potPin);
    // Map the potentiometer value to temperature range
    targetTemp = map(potValue, 0, 4095, minTemp * 10, maxTemp * 10) / 10.0;
  }

  void updateTemperature() {
    // Get temperature reading
    float currentTemp = thermistor->readTemperature();

    // Update rolling average
    tempTotal = tempTotal - tempReadings[readIndex];
    tempReadings[readIndex] = currentTemp;
    tempTotal = tempTotal + currentTemp;

    readIndex++;
    if (readIndex >= AVERAGE_SIZE) {
      readIndex = 0;
      arrayFilled = true;
    }
  }

  float getAverageTemperature() {
    if (arrayFilled) {
      return tempTotal / AVERAGE_SIZE;
    } else {
      return tempTotal / (readIndex == 0 ? 1 : readIndex);
    }
  }

  void controlHeatPad(float avgTemp) {
    // Check if temperature is within range
    bool tempInRange = (avgTemp >= (targetTemp - tempRange)) && (avgTemp <= (targetTemp + tempRange));

    // Control heat pad based on average temperature
    if (avgTemp < (targetTemp - tempRange)) {
      // Temperature is below target range, turn heat pad ON
      digitalWrite(heatPadPin, HIGH);
      heatPadOn = true;

      // Turn on heating LED, turn off ready LED
      digitalWrite(heatingLED, HIGH);
      digitalWrite(readyLED, LOW);
    } else if (avgTemp > (targetTemp + tempRange)) {
      // Temperature is above target range, turn heat pad OFF
      digitalWrite(heatPadPin, LOW);
      heatPadOn = false;

      // Turn off both LEDs when above range
      digitalWrite(heatingLED, LOW);
      digitalWrite(readyLED, LOW);
    } else {
      // Temperature is within target range
      // Turn on ready LED
      digitalWrite(readyLED, HIGH);

      // Turn off when above target to prevent overshooting
      if (avgTemp > targetTemp) {
        digitalWrite(heatPadPin, LOW);
        digitalWrite(heatingLED, LOW);
        heatPadOn = false;
      } else {
        // If we're in range but below target, keep heating
        digitalWrite(heatPadPin, HIGH);
        digitalWrite(heatingLED, HIGH);
        heatPadOn = true;
      }
    }

    // Print results
    Serial.print("Target: ");
    Serial.print(targetTemp, 1);
    Serial.print("F, Current: ");
    Serial.print(avgTemp, 1);
    Serial.print("F, Heat: ");
    Serial.print(heatPadOn ? "ON" : "OFF");
    Serial.print(", Status: ");
    Serial.println(tempInRange ? "IN RANGE" : "OUT OF RANGE");
  }

  void update() {
    updateTargetTemperature();
    updateTemperature();
    float avgTemp = getAverageTemperature();
    controlHeatPad(avgTemp);
  }
};

// Global objects
TemperatureControl* tempControl;

void setup() {
  Serial.begin(9600);

  // Create temperature control object with pins
  tempControl = new TemperatureControl(25, 33, 32, 26, 27);
  tempControl->setup();
}

void loop() {
  tempControl->update();
}