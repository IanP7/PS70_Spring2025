/*
  Rui Santos & Sara Santos - Random Nerd Tutorials
  Modified project based on:
  - https://RandomNerdTutorials.com/esp32-web-server-websocket-sliders/
  - https://RandomNerdTutorials.com/esp32-websocket-server-sensor/
  
  Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files.
  The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
*/

#include <Arduino.h>
#include <WiFi.h>
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include <Arduino_JSON.h>
#include <Adafruit_BMP280.h>
#include <Adafruit_Sensor.h>

// Replace with your network credentials
const char* ssid = "MAKERSPACE";
const char* password = "12345678";

// Create AsyncWebServer object on port 80
AsyncWebServer server(80);

// Create a WebSocket object
AsyncWebSocket ws("/ws");

// Set LED GPIO
const int ledPin1 = 12;
const int ledPin2 = 13;
const int ledPin3 = 14;

// LED control variables
String message = "";
bool ledState1 = false;
bool ledState2 = false;
bool ledState3 = false;

// Json Variable to Hold LED States
JSONVar ledStates;

// Json Variable to Hold Sensor Readings
JSONVar readings;

// Timer variables for sensor readings
unsigned long lastTime = 0;
unsigned long timerDelay = 3000;

// Create a sensor object
Adafruit_BMP280 bmp;

const char index_html[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
    <title>ESP32 IOT DASHBOARD</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        /* Combined CSS for ESP32 Dashboard */
        html {
          font-family: Arial, Helvetica, sans-serif;
          display: inline-block;
          text-align: center;
        }
        
        h1 {
          font-size: 1.8rem;
          color: white;
        }
        
        h2 {
          font-size: 1.5rem;
          color: #034078;
        }
        
        .topnav {
          overflow: hidden;
          background-color: #0A1128;
          padding: 10px;
        }
        
        body {
          margin: 0;
          background-color: #f4f4f4;
        }
        
        .content {
          padding: 20px;
          max-width: 1200px;
          margin: 0 auto;
        }
        
        .section-title {
          margin: 30px 0 10px 0;
        }
        
        .card-grid {
          max-width: 1000px;
          margin: 0 auto 20px auto;
          display: grid;
          grid-gap: 2rem;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        }
        
        .card {
          background-color: white;
          box-shadow: 2px 2px 12px 1px rgba(140,140,140,.5);
          padding: 15px;
          border-radius: 5px;
        }
        
        .card-title {
          font-size: 1.2rem;
          font-weight: bold;
          color: #034078;
          margin-bottom: 10px;
        }
        
        .reading {
          font-size: 1.6rem;
          color: #1282A2;
        }
        
        .state {
          font-size: 1.2rem;
          color: #1282A2;
        }
        
        .toggle-btn {
          background-color: #034078;
          color: white;
          padding: 14px 20px;
          margin: 10px 0;
          border: none;
          border-radius: 4px;
          cursor: pointer;
          font-size: 1rem;
          width: 150px;
          transition: background-color 0.3s;
        }
        
        .toggle-btn:hover {
          background-color: #1282A2;
        }
        
        .toggle-btn:active {
          background-color: #0A1128;
        }
        
        .toggle-btn.on {
          background-color: #1282A2;
        }
    </style>
</head>
<body>
    <div class="topnav">
        <h1>ESP32 DASHBOARD</h1>
    </div>
    <div class="content">
        <!-- Sensor Readings Section -->
        <div class="section-title">
            <h2>Sensor Readings</h2>
        </div>
        <div class="card-grid">
            <div class="card">
                <p class="card-title">Temperature</p>
                <p class="reading"><span id="temperature">0</span> &deg;C</p>
            </div>
            <div class="card">
                <p class="card-title">Pressure</p>
                <p class="reading"><span id="pressure">0</span> hPa</p>
            </div>
        </div>
        
        <!-- LED Control Section -->
        <div class="section-title">
            <h2>LED Controls</h2>
        </div>
        <div class="card-grid">
            <div class="card">
                <p class="card-title">LED 1</p>
                <p>
                    <button id="button1" class="toggle-btn">Turn ON</button>
                </p>
                <p class="state">State: <span id="ledState1">OFF</span></p>
            </div>
            <div class="card">
                <p class="card-title">LED 2</p>
                <p>
                    <button id="button2" class="toggle-btn">Turn ON</button>
                </p>
                <p class="state">State: <span id="ledState2">OFF</span></p>
            </div>
            <div class="card">
                <p class="card-title">LED 3</p>
                <p>
                    <button id="button3" class="toggle-btn">Turn ON</button>
                </p>
                <p class="state">State: <span id="ledState3">OFF</span></p>
            </div>
        </div>
    </div>
    <script>
        // Combined JavaScript for ESP32 Dashboard
        var gateway = `ws://${window.location.hostname}/ws`;
        var websocket;
        
        // Initialize when the page loads
        window.addEventListener('load', onLoad);
        
        function onLoad(event) {
          console.log("loading...");
          // Initialize button listeners
          document.getElementById("button1").addEventListener("click", function() { toggleLED(1); });
          document.getElementById("button2").addEventListener("click", function() { toggleLED(2); });
          document.getElementById("button3").addEventListener("click", function() { toggleLED(3); });
          
          initWebSocket();
        }
        
        function initWebSocket() {
          console.log('Trying to open a WebSocket connection...');
          websocket = new WebSocket(gateway);
          websocket.onopen = onOpen;
          websocket.onclose = onClose;
          websocket.onmessage = onMessage;
        }
        
        function onOpen(event) {
          console.log('Connection opened');
          // Get initial values
          getLedStates();
          getReadings();
        }
        
        function onClose(event) {
          console.log('Connection closed');
          setTimeout(initWebSocket, 2000);
        }
        
        // Function to get LED states
        function getLedStates() {
          if (websocket.readyState === websocket.OPEN) {
            websocket.send("getLedStates");
          }
        }
        
        // Function to get sensor readings
        function getReadings() {
          if (websocket.readyState === websocket.OPEN) {
            websocket.send("getReadings");
          }
        }
        
        // Function to toggle LED states
        function toggleLED(ledNumber) {
          console.log("Toggle LED " + ledNumber);
          if (websocket.readyState === websocket.OPEN) {
            websocket.send(ledNumber + "t"); // Send toggle command
          }
        }
        
        // Function to set LED to specific state
        function setLED(ledNumber, state) {
          console.log("Set LED " + ledNumber + " to " + state);
          if (websocket.readyState === websocket.OPEN) {
            websocket.send(ledNumber + ":" + state); // Send direct state command
          }
        }
        
        // Process incoming messages
        function onMessage(event) {
          console.log("WebSocket message received:", event.data);
          try {
            var myObj = JSON.parse(event.data);
            
            // Process sensor readings
            if (myObj.hasOwnProperty("temperature")) {
              document.getElementById("temperature").innerHTML = myObj.temperature;
              document.getElementById("pressure").innerHTML = myObj.pressure;
            }
            
            // Process LED states
            if (myObj.hasOwnProperty("ledState1")) {
              updateLEDState(1, myObj.ledState1);
              updateLEDState(2, myObj.ledState2);
              updateLEDState(3, myObj.ledState3);
            }
          } catch (e) {
            console.error("Error parsing WebSocket message:", e);
          }
        }
        
        // Update LED state display
        function updateLEDState(ledNumber, state) {
          var displayElement = document.getElementById("ledState" + ledNumber);
          var buttonElement = document.getElementById("button" + ledNumber);
          
          if (state === "1") {
            displayElement.innerHTML = "ON";
            displayElement.style.color = "#34c759";
            buttonElement.classList.add("on");
            buttonElement.innerHTML = "Turn OFF";
          } else {
            displayElement.innerHTML = "OFF";
            displayElement.style.color = "#ff3b30";
            buttonElement.classList.remove("on");
            buttonElement.innerHTML = "Turn ON";
          }
        }
        
        // Request sensor readings at regular intervals
        setInterval(function() {
          getReadings();
        }, 3000); // Update every 3 seconds
    </script>
</body>
</html>
)rawliteral";

// Initialize BMP280 sensor
void initBMP() {
  if (!bmp.begin(0x76)) {
    Serial.println("Could not find a valid BMP280 sensor, check wiring!");
    while (1);
  }
  Serial.println("BMP280 sensor initialized");
}

// Get Sensor Readings and return JSON object
String getSensorReadings() {
  readings["temperature"] = String(bmp.readTemperature());
  readings["pressure"] = String(bmp.readPressure() / 100.0F);
  String jsonString = JSON.stringify(readings);
  return jsonString;
}

// Get LED States
String getLedStates() {
  ledStates["ledState1"] = ledState1 ? "1" : "0";
  ledStates["ledState2"] = ledState2 ? "1" : "0";
  ledStates["ledState3"] = ledState3 ? "1" : "0";
  String jsonString = JSON.stringify(ledStates);
  return jsonString;
}

// Initialize WiFi
void initWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);
  Serial.print("Connecting to WiFi ..");
  while (WiFi.status() != WL_CONNECTED) {
    Serial.print('.');
    delay(1000);
  }
  Serial.println(WiFi.localIP());
}

void notifyClients(String jsonString) {
  ws.textAll(jsonString);
}

void handleWebSocketMessage(void *arg, uint8_t *data, size_t len) {
  AwsFrameInfo *info = (AwsFrameInfo*)arg;
  if (info->final && info->index == 0 && info->len == len && info->opcode == WS_TEXT) {
    data[len] = 0;
    message = (char*)data;
    Serial.print("Received WebSocket message: ");
    Serial.println(message);
    
    // Handle LED toggle commands
    if (message.indexOf("1t") >= 0) {
      // Toggle LED 1
      ledState1 = !ledState1;
      digitalWrite(ledPin1, ledState1 ? HIGH : LOW);
      Serial.println("LED 1: " + String(ledState1 ? "ON" : "OFF"));
      notifyClients(getLedStates());
    }
    else if (message.indexOf("2t") >= 0) {
      // Toggle LED 2
      ledState2 = !ledState2;
      digitalWrite(ledPin2, ledState2 ? HIGH : LOW);
      Serial.println("LED 2: " + String(ledState2 ? "ON" : "OFF"));
      notifyClients(getLedStates());
    }    
    else if (message.indexOf("3t") >= 0) {
      // Toggle LED 3
      ledState3 = !ledState3;
      digitalWrite(ledPin3, ledState3 ? HIGH : LOW);
      Serial.println("LED 3: " + String(ledState3 ? "ON" : "OFF"));
      notifyClients(getLedStates());
    }
    // Handle direct LED state commands
    else if (message.indexOf("1:1") >= 0) {
      ledState1 = true;
      digitalWrite(ledPin1, HIGH);
      Serial.println("LED 1: ON");
      notifyClients(getLedStates());
    }
    else if (message.indexOf("1:0") >= 0) {
      ledState1 = false;
      digitalWrite(ledPin1, LOW);
      Serial.println("LED 1: OFF");
      notifyClients(getLedStates());
    }
    else if (message.indexOf("2:1") >= 0) {
      ledState2 = true;
      digitalWrite(ledPin2, HIGH);
      Serial.println("LED 2: ON");
      notifyClients(getLedStates());
    }
    else if (message.indexOf("2:0") >= 0) {
      ledState2 = false;
      digitalWrite(ledPin2, LOW);
      Serial.println("LED 2: OFF");
      notifyClients(getLedStates());
    }
    else if (message.indexOf("3:1") >= 0) {
      ledState3 = true;
      digitalWrite(ledPin3, HIGH);
      Serial.println("LED 3: ON");
      notifyClients(getLedStates());
    }
    else if (message.indexOf("3:0") >= 0) {
      ledState3 = false;
      digitalWrite(ledPin3, LOW);
      Serial.println("LED 3: OFF");
      notifyClients(getLedStates());
    }
    // Handle data requests
    else if (strcmp((char*)data, "getLedStates") == 0) {
      notifyClients(getLedStates());
    }
    else if (strcmp((char*)data, "getReadings") == 0) {
      notifyClients(getSensorReadings());
    }
  }
}

void onEvent(AsyncWebSocket *server, AsyncWebSocketClient *client, AwsEventType type, void *arg, uint8_t *data, size_t len) {
  switch (type) {
    case WS_EVT_CONNECT:
      Serial.printf("WebSocket client #%u connected from %s\n", client->id(), client->remoteIP().toString().c_str());
      // Send current states to newly connected client
      notifyClients(getLedStates());
      notifyClients(getSensorReadings());
      break;
    case WS_EVT_DISCONNECT:
      Serial.printf("WebSocket client #%u disconnected\n", client->id());
      break;
    case WS_EVT_DATA:
      handleWebSocketMessage(arg, data, len);
      break;
    case WS_EVT_PONG:
    case WS_EVT_ERROR:
      break;
  }
}

void initWebSocket() {
  ws.onEvent(onEvent);
  server.addHandler(&ws);
}

void setup() {
  Serial.begin(115200);
  
  // Initialize LED pins
  pinMode(ledPin1, OUTPUT);
  pinMode(ledPin2, OUTPUT);
  pinMode(ledPin3, OUTPUT);
  
  // Set initial LED states to OFF
  digitalWrite(ledPin1, LOW);
  digitalWrite(ledPin2, LOW);
  digitalWrite(ledPin3, LOW);
  
  // Initialize components
  initBMP();
  initWiFi();
  initWebSocket();
  
  // Web Server Root URL
  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request){
    request->send_P(200, "text/html", index_html);
  });
  
  // Start server
  server.begin();
  
  Serial.println("HTTP server started");
}

void loop() {
  // Send sensor data periodically
  if ((millis() - lastTime) > timerDelay) {
    String sensorReadings = getSensorReadings();
    Serial.println("Sending new sensor readings: " + sensorReadings);
    notifyClients(sensorReadings);
    lastTime = millis();
  }
  
  // Clean up disconnected clients
  ws.cleanupClients();
}